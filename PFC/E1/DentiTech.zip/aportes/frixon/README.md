
# Aporte de Frixon Morán Pilaguano

## Entrega E1 - DentiTech

Responsable: Morán Pilaguano Frixon Fernando

Áreas de contribución:
- Plan de elicitación de requisitos.
- Selección de técnicas por rol.
- Cronograma de sesiones.
- Protocolo de anonimización.
- Custodia y protección de datos personales.
- Consentimiento informado.

## Ubicación del contenido

El aporte de Frixon se encuentra integrado en
main.tex, dentro de la sección:

Plan de Elicitación de Requisitos.

Se conserva esta referencia para identificar
la participación del integrante y evitar
duplicaciones en el documento final.

% ==========================================================
% APORTE INDIVIDUAL: MORAN PILAGUANO FRIXON FERNANDO
% Responsable del plan de elicitacion, instrumentos,
% proteccion de datos, custodia y consentimiento informado.
% Su contenido se conserva directamente en main.tex
% para evitar duplicaciones.
% ==========================================================
